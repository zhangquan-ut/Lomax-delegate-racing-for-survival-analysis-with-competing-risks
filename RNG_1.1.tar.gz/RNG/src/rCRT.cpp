#include <RcppArmadillo.h>
#include <Rcpp.h>
using namespace Rcpp;		// shorthand
// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::interfaces(r, cpp)]]
//' Random number generator for Chinese restaurant table distribution.
//' 
//' @param n A single integer defining the number of random numbers to be generated.
//' @param N A numeric vector for the number of customers.
//' @param r A numeric vector for the concentration parameter.
//' @export
// [[Rcpp::export]]
SEXP rCRT(int n, NumericVector N, NumericVector r) {
    if(n==0) return R_NilValue;
    int m=r.size();
    if (m != N.size()) 
    {
        stop("N and r must have same length");
    }
    int k=n/m;
    int d=n-k*m;
    int i,j,l;
    double ll;
    NumericVector y(n, 0.0);
    double yy;
    if(k>0)
    {
      for(i=0; i<k; i++)
        for(j=0;j<m;j++)
        {
            
            if(N[j]==0)
            {
                y[i*m+j]=0;
            }
            else if(r[j]==0)
            {
                y[i*m+j]=1;
            }
            else
            for(l=0;l<N[j];l++)
            {
                
                yy=R::rbinom(1, r[j]/(r[j]+l)) ;
                y[i*m+j]=y[i*m+j] + yy;
            }
        }
    }
    
    for(j=0;j<d;j++)
    {
            if(N[j]==0)
            {
                y[k*m+j]=0;
            }
            else if(r[j]==0)
            {
                y[k*m+j]=1;
            }
            else
            for(l=0;l<N[j];l++)
            {
                
                yy=R::rbinom(1, r[j]/(r[j]+l)) ;
                y[k*m+j]=y[k*m+j] + yy ;
            }
    }
    
    return y;
}

