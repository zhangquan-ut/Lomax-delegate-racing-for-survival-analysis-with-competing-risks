#include <RcppArmadillo.h>
#include <Rcpp.h>
using namespace Rcpp;		// shorthand
// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::interfaces(r, cpp)]]
//' truncated poisson random number generator
//' 
//' @param n A single integer defining the number of random numbers to be generated.
//' @param lambda A numeric vector for the truncated poisson parameters.
//' @export
// [[Rcpp::export]]
SEXP trunc_pois(int n, NumericVector lambda) {
    if(n==0) return R_NilValue;
    int m=lambda.size();
    int k=n/m;
    int d=n-k*m;
    int i,j;
    NumericVector y(n);
    //NumericVector temp(1), temp2(1), u(1);
    double temp, temp2, u;
    if(k>0)
    {
      for(i=0; i<k; i++)
        for(j=0;j<m;j++)
        {
            if(lambda[j]>=1)
            {   
                temp =R::rpois( lambda[j]);
                while(temp <1) temp =R::rpois( lambda[j]);
                y[i*m+j]=temp ;
            }
            else
            {
                temp2 =R::rpois( lambda[j]);
                u =R::runif(0, 1);
                while(u >=1/(temp2 +1))
                {
                    temp2 =R::rpois( lambda[j]);
                    u =R::runif(0, 1);
                }
                y[i*m+j]=temp2 +1.0;
            }  
        }
    }
    
    for(j=0;j<d;j++)
    {
            if(lambda[j]>=1)
            {
                temp =R::rpois( lambda[j]);
                while(temp <=0) temp =R::rpois( lambda[j]);
                y[k*m+j]=temp ;
            }
            else
            {
                temp2 =R::rpois( lambda[j]);
                u =R::runif(0, 1);
                while(u >=1/(temp2 +1))
                {
                    temp2 =R::rpois( lambda[j]);
                    u =R::runif(0, 1);
                }
                y[k*m+j]=temp2 +1.0;
            }
    }
    
    return y;
}

