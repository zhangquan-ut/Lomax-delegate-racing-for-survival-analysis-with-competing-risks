#include <RcppArmadillo.h>
#include <Rcpp.h>
using namespace Rcpp;		// shorthand
// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::interfaces(r, cpp)]]
//' multivariate normal random number generator
//' 
//' @param n A single integer defining the number of random numbers to be generated.
//' @param mu A numeric vector for mean.
//' @param sigma A symmetric and positive definite matrix covariance or precision matrix.
//' @param eps A small positive number adding to diagonal of sigma if sigma cannot be cholesky decomposed.
//' @param precision sigma is the precision matrix if presicion=T. Otherwise sigma is the covariance matrix.
//' @param cov_mu Mean of the MVN will be product of the covariance (\code{sigma} if precision=F, \code{inv(sigma)} if precision=T) and \code{mu} if cov_mu=T. Otherwise, the mean vector of the MVN is \code{mu}. This is often used in Gibbs sampling of MVN given the precision matrix.
//' @param add Add eps to the diagonal elements of sigma if add=T.
//' @param warn Show warnings of non-positive definite sigma if warn=T.
//' @export
// [[Rcpp::export]]


SEXP c_mvrnorm(int n, arma::vec mu, arma::mat sigma,  double eps=0.00001, bool precision=false, bool cov_mu=false, bool add=false, bool warn=false ) {
    if(n==0) return R_NilValue;
    if(eps<0) stop("eps must be non-negative");
    int ncols = sigma.n_cols;
    if(ncols!=mu.size()) stop("dimenstion of mu and sigma do not match");
    arma::mat Y = arma::randn(n, ncols);
    arma::mat II=arma::eye(ncols, ncols);
    arma::vec mu2(ncols);
    mu2=mu;
    bool success = false;   
    int i=0;
    List res;
    if(!precision)
    {
        arma::mat R(ncols,ncols);
        arma::mat invR(ncols,ncols);
        while(success == false )
        {
            success = chol(R, sigma);
            if(success == false)
            {
                if(!add) stop("sigma is not positive-definite");
                i++;
                sigma += arma::eye(ncols,ncols) * eps;
            }
        }
//        invR=arma::solve(R, II);
        invR=arma::solve(arma::trimatu(R), II); // faster if indicate R as triangular matrix
        if(cov_mu)
            mu2=sigma*mu;
        arma::mat x=arma::repmat(mu2, 1, n).t() + Y * R;
        res["add.times"]=i;
        res["x"]=x;
        res["inv"]=invR*invR.t();
    }
    else
    {
        arma::mat L(ncols,ncols);
        arma::mat invL(ncols, ncols);
        arma::mat invmat(ncols,ncols);
        while(success == false )
        {
            success = chol(L, sigma, "lower"); // sigma=LL'
            if(success == false)
            {
                
                if(!add) stop("sigma is not positive-definite");
                i++;
                sigma += arma::eye(ncols,ncols) * eps;
            }
        }
      //   invL=arma::solve(L, II);
        invL=arma::solve(trimatl(L), II); // inv(sigma)=invL'invL // faster if indicate L as triangular matrix
        invmat=invL.t()*invL; // this is sigma^{-1}
        if(cov_mu)
            mu2=invmat*mu;
        //std::cout<<"here";
        arma::mat x=arma::repmat(mu2, 1, n).t() + Y * invL;
        res["add.times"]=i;
        res["x"]=x;
        res["inv"]=invmat;
        
    }
    if(i>0 && warn) warning("sigma is not positive-definite");
    return res;
}

/*
library(RNG)
library(MASS)
library(Rcpp)
library(RcppArmadillo)
sourceCpp("c_mvrnorm.cpp")
m=matrix(c(1,0,2,0,2,3,2,3,8),3)
mm=m
mm[2,3]=mm[3,2]=2.5

x=c_mvrnorm(n=10^6, mu=c(-2,0,3), sigma=mm, precision=T, cov_mu=T,add=F)

x=c_mvrnorm(n=10^6, mu=c(-2,0,3), sigma=m, precision=T, cov_mu=T,add=T)

 
system.time(x<-c_mvrnorm(10^6, c(-2,0,3), m, add=T))
system.time(y<-mvrnorm(10^6, c(-2,0,3), mm))

library(Rcpp)
library(RcppArmadillo)
sourceCpp("c_mvrnorm.cpp")
sourceCpp("chold.cpp")

m=matrix(c(1,0,2,0,2,3,2,3,8),3)
mm=m
mm[2,3]=mm[3,2]=2.5
x=cov(t(c_mvrnorm(10^4, c(0,0,0), mm)$x))
x=x+diag(rep(1,10^4))
system.time(res<-chold(x))
# v.s.
system.time(res<-chol(x))

*/

