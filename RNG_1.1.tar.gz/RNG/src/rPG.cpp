#include <RcppArmadillo.h>
#include <Rcpp.h>
using namespace Rcpp;		// shorthand
// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::interfaces(r, cpp)]]
//' Random number generator for Polya gamma distribution.
//' 
//' @param n A single integer defining the number of random numbers to be generated.
//' @param h A numeric vector for the shape parameter. 
//' @param z A numeric vector for the parameter associated with tilting.
//' @param trunc An integer for finite truncation approximation.
//' @export
// [[Rcpp::export]]
SEXP rPG(int n, NumericVector h, NumericVector z, int trunc=3) {
    if(n==0) return R_NilValue;
    //std::cout<<"begin ";
    int m=h.size();
    if (m != z.size()) 
    {
        stop("h and z must have same length");
    }
    int i,j,l;
    for(i=0;i<m;i++) if(h[i]<0) stop("h must be non-negative");
    NumericVector zz=abs(z);
    int k=n/m;
    int d=n-k*m;
    double ll;
    NumericVector y(n, 0.0);
    double yhat, ydelta=0.0, Eyhat, Varyhat, mudelta, sig2delta;
    double pi=3.1415926;
    if(k>0)
    {
      for(i=0; i<k; i++)
        for(j=0;j<m;j++)
        {
            if(h[j]==0)
            {
                y[i*m+j]=0.0;
                //std::cout<<"h=0 ";
            }
            else if(zz[j]> exp(16))
            {
                y[i*m+j]=h[j]/(2*zz[j]);
                //std::cout<<"z large ";
            }
            else
            {
                //sample yhat, and calculate E(yhat) and Var(yhat);
                yhat=0.0;
                Eyhat=0.0;
                Varyhat=0.0;
                for(l=1;l<trunc+1;l++)
                {
                    yhat=yhat+R::rgamma(h[j],1)/((l-0.5)*(l-0.5)+zz[j]*zz[j]/(4*pi*pi));
                    Eyhat=Eyhat+h[j]/((l-0.5)*(l-0.5)+zz[j]*zz[j]/(4*pi*pi));
                    Varyhat=Varyhat+ h[j] / (((l-0.5)*(l-0.5)+zz[j]*zz[j]/(4*pi*pi))*((l-0.5)*(l-0.5)+zz[j]*zz[j]/(4*pi*pi)));
                }
                yhat=yhat/(2*pi*pi);
                Eyhat=Eyhat/(2*pi*pi);
                Varyhat=Varyhat/(4*pi*pi*pi*pi);
                //std::cout<<"yhat";
                
                if(zz[j]<0.0001)// zz --> 0;
                {
                    mudelta=0.25*h[j]-Eyhat;
                    sig2delta=h[j]/24.0-Varyhat;
                    //std::cout<<" zz[j]<0.0001";
                }
                else
                {
                    mudelta=0.5*exp(log(h[j])-log(zz[j])+log(tanh(0.5*zz[j])))-Eyhat;
                    sig2delta=0.5*exp(log(h[j])-3*log(zz[j]))*(tanh(zz[j]) -exp(log(zz[j])-log(cosh(zz[j])) ) )/(1+1/cosh(zz[j]))-Varyhat;
                    //std::cout<<" zz[j]>0.0001";
                }
                
                
                if(sig2delta<=0) ydelta=mudelta;
                else if(mudelta<=0)
                {
                    mudelta=exp(-740);
                    ydelta=R::rgamma( exp(2*log(mudelta) -log(sig2delta) ) ,1) * exp(log(sig2delta)- log(mudelta));
                }
                else ydelta=R::rgamma( exp(2*log(mudelta) -log(sig2delta) ) ,1) * exp(log(sig2delta)- log(mudelta));
                
                /*
                if(sig2delta<=0) sig2delta=exp(-740);
                if(mudelta<=0) mudelta=exp(-740);
                ydelta=R::rgamma( exp(2*log(mudelta) -log(sig2delta) ) ,1) * exp(log(sig2delta)- log(mudelta));
                */
                //std::cout<<" ydelta";
                /*
                if(sig2delta>0 && mudelta>0)
                    ydelta=R::rgamma( exp(2*log(mudelta) -log(sig2delta) ) ,1) * exp(log(sig2delta)- log(mudelta));
                else ydelta=0.0;    
                */
                y[i*m+j]=yhat+ydelta;
            }
        }
    }
    
    for(j=0;j<d;j++)
    {
        //std::cout<<"here\n";
            if(h[j]==0)
            {
                y[k*m+j]=0;
            }
            else if(zz[j]> exp(16))
            {
                y[k*m+j]=h[j]/(2*zz[j]);
            }
            else
            {
                //sample yhat, and calculate E(yhat) and Var(yhat);
                yhat=0.0;
                Eyhat=0.0;
                Varyhat=0.0;
                for(l=1;l<trunc+1;l++)
                {
                    yhat=yhat+R::rgamma(h[j],1)/((l-0.5)*(l-0.5)+zz[j]*zz[j]/(4*pi*pi));
                    Eyhat=Eyhat+h[j]/((l-0.5)*(l-0.5)+zz[j]*zz[j]/(4*pi*pi));
                    Varyhat=Varyhat+ h[j] / (((l-0.5)*(l-0.5)+zz[j]*zz[j]/(4*pi*pi))*((l-0.5)*(l-0.5)+zz[j]*zz[j]/(4*pi*pi)));
                }
                yhat=yhat/(2*pi*pi);
                Eyhat=Eyhat/(2*pi*pi);
                Varyhat=Varyhat/(4*pi*pi*pi*pi);
                
                
                if(zz[j]<0.0001)// zz --> 0;
                {
                    mudelta=0.25*h[j]-Eyhat;
                    sig2delta=h[j]/24.0-Varyhat;
                }
                else
                {
                    mudelta=0.5*exp(log(h[j])-log(zz[j])+log(tanh(0.5*zz[j])))-Eyhat;
                    sig2delta=0.5*exp(log(h[j])-3*log(zz[j]))*(tanh(zz[j]) -exp(log(zz[j])-log(cosh(zz[j])) ) )/(1+1/cosh(zz[j]))-Varyhat;
                }
                
                
                if(sig2delta<=0) ydelta=mudelta;
                else if(mudelta<=0)
                {
                    mudelta=exp(-740);
                    ydelta=R::rgamma( exp(2*log(mudelta) -log(sig2delta) ) ,1) * exp(log(sig2delta)- log(mudelta));
                }
                else ydelta=R::rgamma( exp(2*log(mudelta) -log(sig2delta) ) ,1) * exp(log(sig2delta)- log(mudelta));
                
                /*                
                if(sig2delta<=0) sig2delta=exp(-740);
                if(mudelta<=0) mudelta=exp(-740);
                ydelta=R::rgamma( exp(2*log(mudelta) -log(sig2delta) ) ,1) * exp(log(sig2delta)- log(mudelta));
                */
                /*
                if(sig2delta>0 && mudelta>0)
                    ydelta=R::rgamma( exp(2*log(mudelta) -log(sig2delta) ) ,1) * exp(log(sig2delta)- log(mudelta));
                else ydelta=0.0; 
                */
                y[k*m+j]=yhat+ydelta;
            }
    }
    //std::cout<<"end\n";
    return y;
}

