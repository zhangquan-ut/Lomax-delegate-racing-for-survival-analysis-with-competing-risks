#' inverse function of logit
#' 
#' Find the log value of one plus an exponential function.
#' @param x A numerical vector or array.
#' @return 1/(1+exp(-x))
#' @export
inv_logit=function(x)
{
    1/(1+exp(-x))
}
