#' log of one plus an exponential function
#' 
#' Find the log value of one plus an exponential function.
#' @param x A numerical vector or array.
#' @return log(1+exp(x))
#' @export
log1pexp=function(x)
{
    temp1=x<=0
    temp2=x>0
    y=x
    y[temp1]=log1p(exp(x[temp1]))
    y[temp2]=x[temp2]+log1p(exp(-x[temp2]))
    return(y)
}
